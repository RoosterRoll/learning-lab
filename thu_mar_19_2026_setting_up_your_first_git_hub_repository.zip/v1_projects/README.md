# Projects

Hands-on experiments and mini-projects.

Each project folder should include a `README.md` with:
- what it does
- parts/tools needed
- wiring notes (if any)
- how to run/build
- what I learned