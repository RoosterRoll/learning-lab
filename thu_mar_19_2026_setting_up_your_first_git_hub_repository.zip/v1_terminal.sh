# create folder
mkdir learning-lab
cd learning-lab

# initialize git
git init

# create folders
mkdir -p notes projects/raspberry-pi projects/arduino scripts

# create starter files
cat > README.md << 'EOF'
# Learning Lab

A starter repo to document my learning journey in:
- IT & cybersecurity fundamentals
- Raspberry Pi & Arduino projects
- Electronics / making
- Scripting and automation

## Structure
- `notes/` - study notes and references
- `projects/` - hands-on builds (Pi / Arduino)
- `scripts/` - small scripts and utilities
EOF

cat > notes/cybersecurity-basics.md << 'EOF'
# Cybersecurity Basics

## Topics I’m learning
- CIA triad
- Authentication vs Authorization
- Basic threat modeling
- Networking fundamentals

## Labs / exercises
- (add items here)
EOF

cat > scripts/README.md << 'EOF'
# Scripts

Small scripts and utilities I write while learning.

> Note: Nothing here should be used for unauthorized access.
EOF

# first commit
git add .
git commit -m "Initial commit: starter structure"

# connect to GitHub (replace URL with your repo URL)
git branch -M main
git remote add origin https://github.com/RoosterRoll/learning-lab.git
git push -u origin main