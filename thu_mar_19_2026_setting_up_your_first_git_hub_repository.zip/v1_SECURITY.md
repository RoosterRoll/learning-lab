# Security Policy

This repository is for learning and lab work.

If you believe you’ve found a security issue in something I published here, please open an issue with non-sensitive details (or contact me privately if needed).