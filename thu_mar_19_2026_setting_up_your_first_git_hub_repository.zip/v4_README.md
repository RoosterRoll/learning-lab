# Learning Lab

This repository documents my learning journey as I transition into **IT & cybersecurity**, while also exploring **electronics/making** with **Raspberry Pi** and **Arduino**.

I’m a **qualified electrician**, so I’m especially interested in the intersection of:
- hardware + software
- networking + communication
- security + reliability

## Goals
- Build consistent learning habits (notes + small projects)
- Practice Git/GitHub workflows (clean commits, clear READMEs)
- Create a portfolio of small, understandable projects

## Repository structure
- `notes/` — study notes (Linux, networking, security fundamentals)
- `projects/` — hands-on builds  
  - `projects/raspberry-pi/` — Pi experiments and mini-projects  
  - `projects/arduino/` — Arduino sketches and hardware tests
- `scripts/` — small scripts/utilities (automation, parsing, helpers)
- `resources/` — links, references, checklists, and tooling notes

## Ground rules
- Everything here is for **learning and lab use** only.
- No tools/scripts are intended for unauthorized access or misuse.

## Next ideas (backlog)
- Raspberry Pi: basic sensor readout + logging
- Arduino: serial communication + simple telemetry
- Networking: small Python scripts to explore sockets / protocols
- Security: notes and safe lab exercises (threats, hardening, fundamentals)

---
Last updated: 2026-03-18