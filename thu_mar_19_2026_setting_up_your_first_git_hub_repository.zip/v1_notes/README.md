# Notes

Short notes as I learn IT, networking, cybersecurity, Linux, and electronics/IoT concepts.

Each note should be:
- brief
- dated (if useful)
- focused on what I learned + what to try next